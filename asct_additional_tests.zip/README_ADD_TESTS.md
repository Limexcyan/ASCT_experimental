# Additional reference tests for ASCT

This package adds `TestPreprocessing.m`, `TestDTF.m`, `TestLocalization.m`, and `TestPipeline.m` under `tests/`.

**Important:** These are deterministic numerical *reference / contract tests*, not tests of ASCT's actual preprocessing, DTF, source-localization, or end-to-end pipeline implementations. `TestPipeline` exercises `make_demo_fixture.m` and `mock_eeg_predict.m` from the existing starter package. For regression protection of real ASCT code, replace the reference calculation with the actual project function call, keeping the expected invariant.

It intentionally does not touch `TestMVAR.m` or `.github/workflows/matlab-tests.yml`.

Requirements: MATLAB with `matlab.unittest`, existing `make_demo_fixture.m` and `mock_eeg_predict.m` at repository root. No real EEG data, third-party toolboxes or trained weights are required.

Local quick run from repository root:

```matlab
addpath(pwd)
results = runtests('tests');
assert(all([results.Passed]))
```

No workflow change should be necessary if `.github/workflows/matlab-tests.yml` uses `select-by-folder: tests`.

If you already have unmerged work, first commit or stash it before switching branches. Prefer a separate PR for each conceptual change, and keep each PR green.
